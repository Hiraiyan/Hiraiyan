/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atm;

import java.util.Scanner;

class ATM {
    public static void wait(int ms)
{
    try
    {
        Thread.sleep(ms);
    }
    catch(InterruptedException ex)
    {
        Thread.currentThread().interrupt();
    }
}
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double balance = 1345.00;
        
        
        while (true) {
        System.out.println("Main Menu");
        System.out.println("\n1. Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Exit\n");
        
        
        int choice = scanner.nextInt();
        if (choice == 1) {
            System.out.println("\nYour balance is " + balance);
            wait(1000);
            
        }   else if (choice == 2){
            System.out.println("\nEnter amount to deposit");
            double deposit = scanner.nextDouble();
            
            if (deposit > 0) {
                balance += deposit;
                System.out.println("\nYour new balance is: " + balance);
            wait(1500);
            } else {
                System.out.println("Invalid input, try again.");
            wait(1000);
            }
            } else if (choice == 3){
                System.out.println("\nEnter amount to withdraw");
            double withdraw = scanner.nextDouble();
            
            if (withdraw > 0 && withdraw <= balance) {
                balance -= withdraw;
                System.out.println("You have successfully withdrawn: " + withdraw);
            wait(500);
                System.out.println("Your new balance is: " + balance);
            wait(1500);
            } else if (withdraw > balance) {
                System.out.println("Insufficient funds.\nTry again.\n");
            wait(1000);
            
            }else {
                System.out.println("Invalid input, try again.");
            wait(1000);
            }
            } else if (choice == 4){
                break;
            }
        
        else {
            System.out.println("Please select a valid choice ");
        }
        
        System.out.println("");
        
        }
    }
}