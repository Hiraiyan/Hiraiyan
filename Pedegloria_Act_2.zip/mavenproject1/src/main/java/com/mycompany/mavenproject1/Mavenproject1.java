/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;
import java.util.Scanner;
/**
 *
 * @author user
 */
public class Mavenproject1 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
     
        System.out.print("Enter the number of your subjects: ");
        int numsub = scanner.nextInt();
        
        int[] grades = new int[numsub];
        int totalsubs = 0;
        int failedsubs = 0;
        
        for (int i = 0; i < numsub; i++) {
        System.out.print("Enter your grade for the subject " + (i + 1) + ": ");
            grades[i] = scanner.nextInt();
        
        totalsubs  += grades[i];
        if (grades[i]<60) {
            failedsubs++;
        }
        }
        
        double avg = (double) totalsubs / numsub;
        
        String performance;
        if (avg>=90) {
            performance = "Excellent";
        } else if(avg>=80) {
            performance = "Good";
        } else if(avg>=70) {
            performance = "Average";
        } else if(avg>=60) {
            performance = "Pass";
        } else {
            performance = "Pass";
        }
        
        System.out.println("\nYour Average Grade is: " + avg);
        System.out.println("\nYour Performance is: " + performance);
        System.out.println("\nYour Failed subjects are: " + failedsubs);
        
        
        scanner.close();
        
        
    }
}

